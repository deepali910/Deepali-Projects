import './App.css';
import Banner from './component/Banner';
import Header from './component/Header';


function App() {
  return (
   <>
   <Header/>
   <Banner/>
   </>
  );
}

export default App;

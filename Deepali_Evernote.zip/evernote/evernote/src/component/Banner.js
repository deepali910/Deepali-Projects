import React from 'react'
import '../component/Banner.css';
import google from '../images/google.png'

export default function Banner() {
    return (
        <div>

            <section className='banner'>
                <div className='container'>
                    <div className='row'>
                        <div className='col-md-6'>
                            <div className='banner-left-text'>
                                <div className='banner-heading'>
                                    <h1>Meet Evernote, Your Second Brain.</h1>
                                </div>
                                <div className='banner-pharagraph'>
                                    <p>Capture , organize , and share note from anywhere. your
                                        bestideas are always with you and always in sync.
                                    </p>
                                </div>
                            </div>
                        </div>

                        <div className='col-md-6'>
                            <div className='banner-right-text'>
                                <div className='banner-right-heading'>
                                    <h4>Sign Up For Free</h4>
                                </div>
                                <div className='banner-email'>
                                    <span className='google'>
                                        <img src={google} />
                                    </span>
                                    <h6>Sign Up Free With Google</h6>
                                </div>

                                <span className='other-option'> OR</span>

                                <form className='banner-right-form'>
                                    <input type={'email'} placeholder="Email"></input>
                                    <input type={'password'} placeholder="Password"></input>
                                </form>
                                <div className='banner-form-pharagraph'>
                                    <p>By clicking sign up i agree to the<span className='strong'> terms of service</span> and <span className='strong'> privacy policy.</span></p>
                                </div>
                                <div className='banner-right-btn'>
                                    <button> Sign Up For Free </button>
                                </div>
                            </div>
                        </div>



                    </div>
                </div>
            </section>

        </div>
    )
}
